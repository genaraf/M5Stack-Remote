                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2746433
QuickyBot - Small robot based on an arduino Nano board whith bluetooth and ultrasonic sensor by magic_mushrooms is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

https://youtu.be/u3WydDwLPMA

QuickyBot is a small development platform for learning arduino programming.

It is based on a Nano arduino card.
It has an ultrasonic distance sensor hc-sr04 to apprehend its environment.
It communicates via bluetooth using a HC-06 card.
It is powered by a 850 mAh LiPo battery.
Its two-wheel drive is powered by two micorservos 9g TowerPro SG90 modified for continuous rotation.

Here are links for modifying servos:
     -   http://www.instructables.com/id/How-to-Make-a-TowerPro-Micro-Servo-Spin-360/
     -   https://learn.adafruit.com/modifying-servos-for-continuous-rotation/overview

QuickyBot can be printed quickly and easily. It is made without much parts and can be made by beginners.
Only the upper shell requires the use of supports during printing.
(I modeled two upper shells because ultrasonic sensors may have slightly different dimensions depending on the manufacturer)

List of pieces :

    1 Nano arduino card
    1 ultrasonic sensor hc-sr04
    1 bluetooth HC-06 card
    1 LiPo battery 850mAh
    1 DCDC Boost converter 0.9v/5v -> 5v 600mA
    1 micro switch
    1 female JST socket
    2 microservo 9g TowerPro SG90
    2 resistors 2.2k
    2 screws 2,5X20
    2 screws 2,5X25
    2 ball bearing 3x8x4 693ZZ
    1 screw 2,5X12 (or 2,5X15)

The electronic part is minimalist and simple to assemble according to the wiring diagram that I give you.

Be free to contact me if you encounter a difficulty to build your QuickyBot and give me a tip if you like my work :)

If you want, I made small arduino programs to start (calibrate the servos to find the complete stopping position of the wheels, change the name of the bluetooth card, control the QuickyBot by bluetooth or let it move in autonomous mode ...) and I also created a minimalist application for android smartphones to remotely control QuickyBots ...


FRENCH :

QuickyBot est une petite plateforme de développement pour l'apprentissage de la programmation sur arduino.

Il est basé sur une carte arduino Nano.
Il possède un capteur de distance ultrason hc-sr04 pour appréhender son environnement.
Il communique par bluetooth grâce à une carte HC-06.
Il est alimenté par une batterie LiPo 850 mAh.
Ses deux roues motrices sont actionnées par deux micorservos 9g TowerPro SG90 modifiés pour la rotation continue.

Voici des liens pour la modification des servos : 
     -   http://www.instructables.com/id/How-to-Make-a-TowerPro-Micro-Servo-Spin-360/
     -   https://learn.adafruit.com/modifying-servos-for-continuous-rotation/overview

QuickyBot peut s'imprimer rapidement et simplement. Il est constitué de peux de pièces et peux être fabriqué par des débutants.
Seule la coque supérieure nécessite l'utilisation de supports au cours de l'impression.
(J'ai modélisé deux coques supérieures car les capteurs ultrason peuvent avoir des dimensions légèrement différentes selon les fabricants)

Liste des pièces :
     -   1 carte arduino Nano
     -   1 capteur ultrason hc-sr04
     -   1 carte bluetooth HC-06
     -   1 batterie LiPo 850mAh
     -   1 Convertisseur boost DCDC 0.9v/5v -> 5v 600mA
     -   1 micro interrupteur
     -   1 prise JST femelle
     -   2 microservo 9g TowerPro SG90
     -   2 résistances 2.2k
     -   2 vis 2,5X20
     -   2 vis 2,5X25
     -   2 roulement à billes 3x8x4 693ZZ
     -   1 vis 2,5X12 (ou 2,5X15)

La partie électronique est minimaliste et simple à assembler en suivant le schéma de câblage que je vous donne.

N'hésitez pas à me contacter si vous rencontrez une difficulté pour construire votre QuickyBot et pensez à me laisser un tips si aimez mon travail :)

Pour ceux que ça intéresse, j'ai fait des petits programmes arduino pour débuter (étalonner les servos pour trouver la position d’arrêt complet des roues, changer le nom de la carte bluetooth, piloter le QuickyBot par bluetooth ou le laisser évoluer en mode autonome...) et j'ai aussi créé une application minimaliste pour les smartphones android afin de commander à distance les QuickyBots...